package Decorator;

public class Bacon extends ItemDecorator{

	public Bacon(Lanche lanche){		
		this.lanche = lanche;
	}
	
	@Override
	public double getCusto() {
		// TODO Auto-generated method stub
		return lanche.getCusto() + 0.8;
	}
	
	public double getCustoItem(){
		return getCusto() - lanche.getCusto();
	}

	@Override
	public String getNome() {
		// TODO Auto-generated method stub
		return lanche.getNome() + ", Bacon";
	}

}
