package Decorator;

public class Bife extends ItemDecorator{

	public Bife(Lanche lanche){		
		this.lanche = lanche;
	}
	
	@Override
	public double getCusto() {
		// TODO Auto-generated method stub
		return lanche.getCusto() + 1.5;
	}

	@Override
	public String getNome() {
		// TODO Auto-generated method stub
		return lanche.getNome() + ", Bife";
	}

}
