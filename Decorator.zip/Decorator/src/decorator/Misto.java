package Decorator;

public class Misto extends Lanche{
	
	public Misto(){
		
		setNome("Misto");
		setCusto(2.00);
		
		
	}

}
