package Decorator;

public class Queijo extends ItemDecorator{

	public Queijo(Lanche lanche){		
		this.lanche = lanche;
	}
	
	@Override
	public double getCusto() {
		// TODO Auto-generated method stub
		return lanche.getCusto() + 0.4;
	}

	@Override
	public String getNome() {
		// TODO Auto-generated method stub
		return lanche.getNome() + ", Queijo";
	}
	
}
