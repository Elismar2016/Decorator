package Decorator;

public class Ovo extends ItemDecorator{

	public Ovo(Lanche lanche){		
		this.lanche = lanche;		
	}
	
	@Override
	public double getCusto() {
		// TODO Auto-generated method stub
		return lanche.getCusto() + 0.5;
	}

	@Override
	public String getNome() {
		// TODO Auto-generated method stub
		return lanche.getNome() + ", Ovo";
	}
}
