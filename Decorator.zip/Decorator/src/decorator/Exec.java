package Decorator;

public class Exec {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Lanche lanche = new Hamburger();
		
		lanche = new Bife(new Bife(new Bife(new Bife(new Ovo(new Queijo(lanche))))));	
		
		
		System.out.println("Custo: " + lanche.getCusto());
		System.out.println("Nome: " +lanche.getNome());
		
		
		
		
	}

}
