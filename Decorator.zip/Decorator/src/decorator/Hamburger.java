package Decorator;

public class Hamburger extends Lanche{

	public Hamburger(){
		
		setNome("Hamburger");
		setCusto(6.00);
		
	}
	
}
