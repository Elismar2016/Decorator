package Decorator;

public abstract class ItemDecorator extends Lanche{

	Lanche lanche;

	public abstract double getCusto(); 
	public abstract String getNome(); 
	
}
